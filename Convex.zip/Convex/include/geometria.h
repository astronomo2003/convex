#ifndef GEOMETRIA_H
#define GEOMETRIA_H

#include <opencv2/opencv.hpp>
#include <vector>

// Utilidades geométricas
double calcularDistancia(cv::Point a, cv::Point b);
int giro(cv::Point a, cv::Point b, cv::Point c);

// Convex Hull (Graham Scan modificado)
std::vector<cv::Point> cascoConvexo(std::vector<cv::Point> puntos);

#endif