#ifndef VISION_H
#define VISION_H

#include <opencv2/opencv.hpp>
#include <vector>

// Escala de grises manual
cv::Mat convertirAGris(const cv::Mat& frame);

// Aplicar kernel (convolución manual)
cv::Mat aplicarKernel(const cv::Mat& img, const std::vector<std::vector<int>>& kernel);

// Detección de bordes con Sobel Magnitude
cv::Mat detectarBordesSobel(const cv::Mat& img);

#endif