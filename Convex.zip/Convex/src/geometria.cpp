#include "../include/geometria.h"
#include <cmath>
#include <algorithm>

// ===== DISTANCIA =====
double calcularDistancia(cv::Point a, cv::Point b){
    return std::sqrt((a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y));
}

// ===== ORIENTACIÓN =====
int giro(cv::Point a, cv::Point b, cv::Point c){
    int val = (b.y - a.y)*(c.x - b.x) - (b.x - a.x)*(c.y - b.y);

    if(val == 0) return 0;
    return (val > 0) ? 1 : 2;
}

// ===== CONVEX HULL =====
std::vector<cv::Point> cascoConvexo(std::vector<cv::Point> puntos){

    if(puntos.size() < 3)
        return puntos;

    // Buscar punto más bajo
    int idx = 0;
    for(int i = 1; i < puntos.size(); i++){
        if(puntos[i].y < puntos[idx].y)
            idx = i;
    }

    std::swap(puntos[0], puntos[idx]);
    cv::Point base = puntos[0];

    // Ordenar por ángulo
    std::sort(puntos.begin()+1, puntos.end(), [base](cv::Point a, cv::Point b){
        int o = giro(base, a, b);

        if(o == 0)
            return calcularDistancia(base,a) < calcularDistancia(base,b);

        return o == 2;
    });

    std::vector<cv::Point> resultado;

    resultado.push_back(puntos[0]);
    resultado.push_back(puntos[1]);
    resultado.push_back(puntos[2]);

    for(int i = 3; i < puntos.size(); i++){

        while(resultado.size() > 1 &&
              giro(resultado[resultado.size()-2],
                   resultado.back(),
                   puntos[i]) != 2){

            resultado.pop_back();
        }

        resultado.push_back(puntos[i]);
    }

    return resultado;
}