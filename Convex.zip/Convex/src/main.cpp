#include <opencv2/opencv.hpp>
#include <iostream>
#include "../include/vision.h"
#include "../include/geometria.h"

int main(){

    // DroidCam (prueba 0 o 1)
    cv::VideoCapture cap(0);

    if(!cap.isOpened()){
        std::cout << "No se pudo abrir la camara\n";
        return -1;
    }

    cv::Mat frame;

    while(cap.read(frame)){

        // ===== PIPELINE =====
        cv::Mat gris = convertirAGris(frame);
        cv::Mat bordes = detectarBordesSobel(gris);

        std::vector<std::vector<cv::Point>> contornos;
        cv::findContours(bordes, contornos, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

        for(int i = 0; i < contornos.size(); i++){

            // Filtrar ruido
            if(contornos[i].size() < 100)
                continue;

            double area = cv::contourArea(contornos[i]);

            if(area < 2000)
                continue;

            // ===== CONVEX HULL =====
            std::vector<cv::Point> hull = cascoConvexo(contornos[i]);

            // ===== APROXIMACIÓN =====
            std::vector<cv::Point> aprox;

            double epsilon = 0.02 * cv::arcLength(hull, true);
            cv::approxPolyDP(hull, aprox, epsilon, true);

            int lados = aprox.size();

            // ===== CLASIFICACIÓN =====
            std::string figura;

            switch(lados){
                case 3: figura = "Triangulo"; break;
                case 4: figura = "Cuadrilatero"; break;
                case 5: figura = "Pentagono"; break;
                case 6: figura = "Hexagono"; break;
                case 7: figura = "Heptagono"; break;
                case 8: figura = "Octagono"; break;
                case 9: figura = "Eneagono"; break;
                case 10: figura = "Decagono"; break;
                default:
                    if(lados > 10 && lados <= 20)
                        figura = "Circulo";
                    else
                        continue;
            }

            // ===== CENTRO =====
            cv::Moments m = cv::moments(contornos[i]);

            if(m.m00 == 0)
                continue;

            int cx = int(m.m10 / m.m00);
            int cy = int(m.m01 / m.m00);

            // ===== DIBUJO =====
            cv::polylines(frame, aprox, true, cv::Scalar(0,255,0), 2);
            cv::circle(frame, cv::Point(cx, cy), 3, cv::Scalar(255,0,0), -1);

            cv::putText(frame, figura,
                        cv::Point(cx - 50, cy),
                        cv::FONT_HERSHEY_SIMPLEX,
                        0.6,
                        cv::Scalar(0,0,255),
                        2);
        }

        cv::imshow("Camara", frame);

        if(cv::waitKey(30) == 27)
            break;
    }

    return 0;
}