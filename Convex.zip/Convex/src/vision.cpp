#include "../include/vision.h"
#include <cmath>

// ===== ESCALA DE GRISES MANUAL =====
cv::Mat convertirAGris(const cv::Mat& frame){
    cv::Mat gris(frame.rows, frame.cols, CV_8UC1);

    for(int i = 0; i < frame.rows; i++){
        for(int j = 0; j < frame.cols; j++){

            cv::Vec3b pixel = frame.at<cv::Vec3b>(i,j);

            int b = pixel[0];
            int g = pixel[1];
            int r = pixel[2];

            int gray = (0.299*r + 0.587*g + 0.114*b);

            gris.at<uchar>(i,j) = gray;
        }
    }

    return gris;
}

// ===== CONVOLUCIÓN MANUAL =====
cv::Mat aplicarKernel(const cv::Mat& img, const std::vector<std::vector<int>>& kernel){
    int k = kernel.size() / 2;

    cv::Mat resultado = cv::Mat::zeros(img.size(), CV_32SC1);

    for(int i = k; i < img.rows - k; i++){
        for(int j = k; j < img.cols - k; j++){

            int suma = 0;

            for(int u = -k; u <= k; u++){
                for(int v = -k; v <= k; v++){
                    suma += img.at<uchar>(i+u, j+v) * kernel[u+k][v+k];
                }
            }

            resultado.at<int>(i,j) = suma;
        }
    }

    return resultado;
}

// ===== SOBEL MAGNITUDE =====
cv::Mat detectarBordesSobel(const cv::Mat& img){

    std::vector<std::vector<int>> sobelX = {
        {-1,0,1},
        {-2,0,2},
        {-1,0,1}
    };

    std::vector<std::vector<int>> sobelY = {
        {-1,-2,-1},
        {0,0,0},
        {1,2,1}
    };

    cv::Mat gx = aplicarKernel(img, sobelX);
    cv::Mat gy = aplicarKernel(img, sobelY);

    cv::Mat bordes = cv::Mat::zeros(img.size(), CV_8UC1);

    for(int i = 0; i < img.rows; i++){
        for(int j = 0; j < img.cols; j++){

            int valX = gx.at<int>(i,j);
            int valY = gy.at<int>(i,j);

            int magnitud = std::sqrt(valX*valX + valY*valY);

            if(magnitud > 100)
                bordes.at<uchar>(i,j) = 255;
        }
    }

    return bordes;
}